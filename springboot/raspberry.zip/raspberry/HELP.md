# Getting Started

### Guides
The following guides illustrates how to use certain features concretely:

* [Accessing Data with MongoDB](https://spring.io/guides/gs/accessing-data-mongodb/)

